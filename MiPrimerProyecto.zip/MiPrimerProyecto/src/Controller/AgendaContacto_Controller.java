/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.AgendaContacto_Model;
import View.AgendaContacto_View;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.JRException;

//Reporte
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;

/**
 *
 * @author carlo
 */
public class AgendaContacto_Controller implements ActionListener{
    
    //Creamos objetos del Model y View
    AgendaContacto_View view;
    AgendaContacto_Model model;
    
    int id_contacto = 0;
    
    /**
     * Este es el metodo constructor de esta clase
     * @param view es el que recibe la vista (Formulario) "AgendaContacto"
     */
    public AgendaContacto_Controller(AgendaContacto_View view){
        
        this.view = view;
        model = new AgendaContacto_Model();
        
        events();
        
    }
    
    
    //Metodo donde se asignan eventos a los componentes (Jbutton, JCombobox)
    private void events(){
        
            view.btnGuardar.addActionListener(this);
            view.btnBuscar.addActionListener(this);
            view.btnNuevo.addActionListener(this);
            view.btnModificar.addActionListener(this);
            view.btnEliminar.addActionListener(this);
            view.btnReporte.addActionListener(this); 
    }
    
    public void limpiarCampos(){
        
        id_contacto = 0;
        view.txtNombre.setText("");
        view.txtCelular.setText("");
        view.txtTelFijo.setText("");
        view.txtDireccion.setText("");
        view.atxtNota.setText("");
        
    }
    
    //Generar Reporte con Datos Estaticos
    public void generarReporteDatosFijos(boolean abrirpdf, String rutareporte, String rutaguardado, String nombrepdf){
        
        try {
            
            JasperReport reporte = (JasperReport) JRLoader.loadObject(new File(rutareporte));
            
            JasperPrint jprint = JasperFillManager.fillReport(reporte, null);
            
            JasperExportManager.exportReportToPdfFile(jprint, rutaguardado+nombrepdf);
            
            if (abrirpdf){
                
                OpenPDF(rutaguardado+nombrepdf);
                 
            }
            
        } catch (JRException e) {
            
            JOptionPane.showMessageDialog(null, e);
            
        }
        
    }
    
    
    public void generarReporteParametros(boolean abrirpdf, String rutareporte, String rutaguardado, String nombrepdf){
        
        try {
            
            JasperReport reporte = (JasperReport) JRLoader.loadObject(new File(rutareporte));
            
            Map<String, Object > parametros = new HashMap<>();
            parametros.put("TipoContactos", "Familiares");
            
            JasperPrint jprint = JasperFillManager.fillReport(reporte, parametros);
            
            JasperExportManager.exportReportToPdfFile(jprint, rutaguardado+nombrepdf);
            
            if (abrirpdf){
                
                OpenPDF(rutaguardado+nombrepdf);
                 
            }
            
        } catch (JRException e) {
            
            JOptionPane.showMessageDialog(null, e);
            
        }
        
    }
    
    
    //metodo para abrir pdf y otros archivos
    public static void OpenPDF (String rutapdf){
        
        try {
            
            File path = new File(rutapdf);
            Desktop.getDesktop().open(path);
            path.deleteOnExit();
            
        } catch (Exception ex) {
            
            JOptionPane.showMessageDialog(null, "Error al abrir pdf"+ex);
            
        }
        
    }
    

    @Override
    public void actionPerformed(ActionEvent e) {
       
        
        //Obtenemos el componente al cual se esta accionando
        Object componente = e.getSource();
        
        //Dependiendo del componente se ejecutara un codigo
        if(componente.equals(view.btnGuardar)){
            
            int resultado = model.guardarDatos(view.txtNombre.getText(), view.txtCelular.getText(), 
                                                view.txtTelFijo.getText(),view.txtDireccion.getText(), view.atxtNota.getText());
            
            
            if (resultado !=0){
                
                JOptionPane.showMessageDialog(null, "Operacion exitosa");
                
                limpiarCampos();
                
            }
            
        }else if(componente.equals(view.btnBuscar)){
            
            Object[] datos = model.consultarDatos(view.txtCelular.getText());
            
            limpiarCampos();
            
            if(datos!=null){
                
                id_contacto = Integer.parseInt(datos[0].toString());
                view.txtNombre.setText(datos[1].toString());
                view.txtCelular.setText(datos[2].toString());
                view.txtTelFijo.setText(datos[3].toString());
                view.txtDireccion.setText(datos[4].toString());
                view.atxtNota.setText(datos[5].toString());
                
            }else{
                JOptionPane.showMessageDialog(null, "No hay contactos con ese celular");
            }
            
        }else if(componente.equals(view.btnModificar)){
            
            if(id_contacto == 0){
                
                JOptionPane.showMessageDialog(null, "No hay informacion para modificar");
                
            }else{
                
                int resultado = model.modificarDatos(view.txtNombre.getText(), view.txtCelular.getText(), 
                                                view.txtTelFijo.getText(),view.txtDireccion.getText(), view.atxtNota.getText(), id_contacto);
            
            
                if (resultado !=0){

                    JOptionPane.showMessageDialog(null, "Operacion exitosa");

                }
                
            }
            
        }else if(componente.equals(view.btnNuevo)){
            
            limpiarCampos();
            
        }else if(componente.equals(view.btnEliminar)){
            
            if(id_contacto == 0){
                
                JOptionPane.showMessageDialog(null, "No hay informacion para eliminar");
                
            }else{
                
                int resultado = model.eliminarDatos(id_contacto);
            
            
                if (resultado !=0){

                    JOptionPane.showMessageDialog(null, "Operacion exitosa");
                    
                    limpiarCampos();

                }
                
            }
            
        }else if(componente.equals(view.btnReporte)){
            
            
            //generarReporteDatosFijos(true, "src/Report/PlanillaContactos.jasper", "src/Report", "PlanillaContactos.pdf");
            generarReporteParametros(true, "src/Report/PlanillaContactosParametros.jasper", "src/Report", "planilla_tipocontactos.pdf");

            
        }
    }
}
