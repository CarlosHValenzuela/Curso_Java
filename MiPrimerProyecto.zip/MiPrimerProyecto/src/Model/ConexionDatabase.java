/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author carlo
 */
public class ConexionDatabase {
    
    //Variables de Configuracion
    private static final String database="agenda";
    private static final String url="jdbc:mysql://localhost:3306/"+database;
    private static final String user="root";
    private static final String password="admin";
    
    //Metodo para establecer la conexion para la base de datos
    public static Connection Conexion(){
        
        //Variable para almacenar la conexion
        Connection conect=null;
        try {
            
            //Registramos el Driver
            Class.forName("org.gjt.mm.mysql.Driver");
            
            //Establecemos la conexion
            conect = DriverManager.getConnection(url, user, password);
            
            
        } catch (ClassNotFoundException | SQLException e) {
            
            //Mostrar un aviso
            JOptionPane.showMessageDialog(null,"Error: "+e);
            
        }
        
        //Retornamos la conexion
        return conect;
        
    }
    
    /**
     * Metodo para cerrar la conexion a la BD
     * @param conn contiene la conexion actual
     */
    public static void cerrarConexion(Connection conn){
        
        try {            
            conn.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar la conexion"+e);
        }
        
    }
    
}
