/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author carlo
 */
public class AgendaContacto_Model {
    
    static ConexionPool conexionpool = new ConexionPool();
    
    
    
    
    public static int guardarDatos(String nombre, String celular, String tel_fijo,
                                    String direccion, String nota){
        
        int resultado = 0;
        Connection conn = null;
        
        String SSQL = "INSERT INTO contacto (nombre_contacto, celular, tel_fijo,"
                + "direccion , nota) VALUES (?, ?, ?, ?, ?)";
        
        try {
            
            conn = conexionpool.datasource.getConnection();
            
            PreparedStatement pst = conn.prepareStatement(SSQL);
            pst.setString(1, nombre);
            pst.setString(2, celular);
            pst.setString(3, tel_fijo);
            pst.setString(4, direccion);
            pst.setString(5, nota);
            
            resultado = pst.executeUpdate();
            
            pst.close();
            
        } catch (SQLException e) {
            
            JOptionPane.showMessageDialog(null, "Error al guardar datos: "+e);
            
        } finally{
            
            conexionpool.liberarConexion(conn);
            
        }
        
        return resultado;
        
    }
    
    
    public static Object[] consultarDatos(String celular){
        
        Object [] datos = null;
        Connection conn = null;
        
        String SSQL = "SELECT  id_contacto,nombre_contacto, celular, tel_fijo, direccion, nota FROM contacto WHERE celular=?";
        
        try {
            
            conn = conexionpool.datasource.getConnection();
            
            PreparedStatement pst = conn.prepareStatement(SSQL);
            pst.setString(1, celular);
            
            ResultSet rs = pst.executeQuery();
            
            if(rs.next()){
                
                datos = new Object[6];
                
                datos[0] = rs.getString("id_contacto");
                datos[1] = rs.getString("nombre_contacto");
                datos[2] = rs.getString("celular");
                datos[3] = rs.getString("tel_fijo");
                datos[4] = rs.getString("direccion");
                datos[5] = rs.getString("nota");
                
            }
            
            pst.close();
            
        } catch (SQLException e) {
            
            JOptionPane.showMessageDialog(null, "Error al buscar datos: "+e);
            
        } finally{
            
            conexionpool.liberarConexion(conn);;
            
        }
        
        return datos;
        
    }
    
    
    public static int modificarDatos(String nombre, String celular, String tel_fijo,
                                    String direccion, String nota, int id_contacto){
        
        int resultado = 0;
        Connection conn = null;
        
        String SSQL = "UPDATE contacto SET nombre_contacto=?, celular=?, tel_fijo=?,"
                + "direccion=? , nota=? WHERE id_contacto=?";
        
        try {
            
            conn = conexionpool.datasource.getConnection();
            
            PreparedStatement pst = conn.prepareStatement(SSQL);
            pst.setString(1, nombre);
            pst.setString(2, celular);
            pst.setString(3, tel_fijo);
            pst.setString(4, direccion);
            pst.setString(5, nota);
            pst.setInt(6, id_contacto);
            
            resultado = pst.executeUpdate();
            
            pst.close();
            
        } catch (SQLException e) {
            
            JOptionPane.showMessageDialog(null, "Error al modificar datos: "+e);
            
        } finally{
            
            conexionpool.liberarConexion(conn);
            
        }
        
        return resultado;
        
    }
    
   
    public static int eliminarDatos(int id_contacto){
        
        int resultado = 0;
        Connection conn = null;
        
        String SSQL = "DELETE FROM contacto WHERE id_contacto=?";
        
        try {
            
            conn = conexionpool.datasource.getConnection();
            
            PreparedStatement pst = conn.prepareStatement(SSQL);
            pst.setInt(1, id_contacto);
            
            resultado = pst.executeUpdate();
            
            pst.close();
            
        } catch (SQLException e) {
            
            JOptionPane.showMessageDialog(null, "Error al eliminar datos: "+e);
            
        } finally{
            
            conexionpool.liberarConexion(conn);
            
        }
        
        return resultado;
        
    }
    
}
