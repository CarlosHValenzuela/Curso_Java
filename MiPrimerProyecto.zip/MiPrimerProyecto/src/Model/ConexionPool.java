/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;


import java.sql.Connection;
import java.sql.SQLException;
import javax.sql.DataSource;
import javax.swing.JOptionPane;
import org.apache.commons.dbcp.BasicDataSource;

/**
 *
 * @author carlo
 */
public class ConexionPool {
    
    public DataSource datasource;
    
    //Variables de Configuracion
    private static final String database="agenda";
    private static final String url="jdbc:mysql://localhost:3306/"+database+"?holdResultsOpenOverStatementClose=true&characterEncodig=UTF-8&characterSetResult=utf8";
    private static final String user="root";
    private static final String password="admin";
    
    public ConexionPool(){
        
        BasicDataSource basicdatasource = new BasicDataSource();
        
        basicdatasource.setDriverClassName("org.gjt.mm.mysql.Driver");
        basicdatasource.setUsername(user);
        basicdatasource.setPassword(password);
        basicdatasource.setUrl(url);
        basicdatasource.setMaxActive(50);
        basicdatasource.setValidationQuery("SELECT 1");
        
        datasource = basicdatasource;
    }
    
    /**
     * Metodo para cerrar la conexion a la BD
     * @param conn contiene la conexion actual
     */
    public static void liberarConexion(Connection conn){
        
        try {    
            if(conn!=null){
                conn.close();
            }    
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al liberar la conexion"+e);
        }
        
    }
    
}
