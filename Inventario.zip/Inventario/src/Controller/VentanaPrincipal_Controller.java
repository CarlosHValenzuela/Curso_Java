/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import View.VentanaPrincipal_View;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;

/**
 *
 * @author carlo
 */
public class VentanaPrincipal_Controller implements ActionListener{
    
    // Creamos objetos
    VentanaPrincipal_View view;
    
    /**
     * Este es el metodo Constructor de esta clase
     * @param view es el que recibe la Vista "VentanaPrincipal_View"
     */
    public VentanaPrincipal_Controller (VentanaPrincipal_View view){
        
        this.view = view;
        
        // Llamamos el metodo para asignar los eventos
        events();
        
    }
    
    
// Asignamos Eventos a los componentes
    public void events(){
        
        view.btn_Inicio.addActionListener(this);
        view.btn_Proveedores.addActionListener(this);
        view.btn_Productos.addActionListener(this);
        view.btn_Entradas.addActionListener(this);
        view.btn_Salidas.addActionListener(this);
        view.btn_Salir.addActionListener(this);
        
    }
    
    
// Mostraremos el modulo correspondiente
    public void mostrar_modulo(int numero_panel){
        
        JPanel paneles []= {view.panel_Inicio, view.panel_Proveedores, view.panel_Productos, 
                            view.panel_Entradas, view.panel_Salidas};
        
        for (int i = 0; i < paneles.length; i++) {
            
            if(numero_panel==i){
                
                paneles[i].setVisible(true);    
                
            }else{
                
                paneles[i].setVisible(false); 
                
            }
            
        }
        
    }
    

    @Override
    public void actionPerformed(ActionEvent e) {
        
        Object evt = e.getSource();
        
        if(evt.equals(view.btn_Salir)){
            
            System.exit(0);
            
        }else if(evt.equals(view.btn_Inicio)){
            
            mostrar_modulo(0);
            
        }else if(evt.equals(view.btn_Proveedores)){
            
            mostrar_modulo(1);
            
        }else if(evt.equals(view.btn_Productos)){
            
            mostrar_modulo(2);
            
        }else if(evt.equals(view.btn_Entradas)){
            
            mostrar_modulo(3);
            
        }else if(evt.equals(view.btn_Salidas)){
            
            mostrar_modulo(4);
            
        }
        
    }
    
}
